<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercise List</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <style>
        /* CSS to limit image size */
        .exercise-image {
            max-width: 80px;
            max-height: 80px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Exercise List</h2>

    <!-- Button to go to create.php -->
    <a href="create.php" class="btn btn-primary mb-3">Add Exercise</a>

    <div class="table-responsive">
        <table class="table table-bordered">
            <thead>
            <tr>
                <th></th>
                <th>Exercise ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Difficulty Level</th>
                <th>Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php
            // Include config file
            require_once "config.php";

            // Fetch exercises from database
            $sql = "SELECT * FROM exercises";
            $result = mysqli_query($link, $sql);

            // Check if any exercises exist
            if (mysqli_num_rows($result) > 0) {
                // Display exercises
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td><img src='img/" . getRandomImage() . "' alt='Exercise GIF' class='exercise-image'></td>"; // Display a random GIF from the folder
                    echo "<td>" . $row["id"] . "</td>";
                    echo "<td>" . $row["name"] . "</td>";
                    echo "<td>" . $row["description"] . "</td>";
                    echo "<td>" . $row["difficulty"] . "</td>";
                    echo "<td>";
                    echo "<a href='update.php?id=" . $row["id"] . "' class='btn btn-sm btn-info mr-1'><i class='fas fa-edit'></i> Edit</a>";
                    echo "<form method='post' action='delete.php' style='display: inline;' onsubmit='return confirm(\"Are you sure you want to delete this exercise?\");'>
                          <input type='hidden' name='exercise_id' value='" . $row["id"] . "'>
                          <button type='submit' name='delete' class='btn btn-sm btn-danger'><i class='fas fa-trash-alt'></i> Delete</button>
                          </form>";
                    echo "<a href='read.php?id=" . $row["id"] . "' class='btn btn-sm btn-secondary'><i class='fas fa-eye'></i> View</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6'>No exercises found.</td></tr>";
            }

            // Close connection
            mysqli_close($link);

            // Function to get a random image from the folder
            function getRandomImage() {
                $files = glob('img/*.*'); // Get all files in the folder
                $randomFile = $files[array_rand($files)]; // Select a random file
                return basename($randomFile); // Return only the filename
            }
            ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Bootstrap JS (Optional) -->
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Font Awesome JS (Optional) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>
</body>
</html>
